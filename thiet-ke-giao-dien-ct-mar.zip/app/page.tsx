'use client'

import { ChangeEvent, useRef, useState } from 'react'
import { CheckCircle2, Image as ImageIcon, Loader2, ScanLine, Upload, XCircle } from 'lucide-react'

const API_URL = 'https://outscore-degrading-doily.ngrok-free.dev/predict'
const SIZE = 512

type Status = 'idle' | 'reading' | 'processing' | 'success' | 'error'

export default function Page() {
  const inputRef = useRef<HTMLInputElement>(null)
  const sourceCanvas = useRef<HTMLCanvasElement>(null)
  const resultCanvas = useRef<HTMLCanvasElement>(null)
  const [file, setFile] = useState<File | null>(null)
  const [status, setStatus] = useState<Status>('idle')
  const [message, setMessage] = useState('Chọn file RAW để bắt đầu')

  const draw = (data: Float32Array, canvas: HTMLCanvasElement | null) => {
    if (!canvas) return
    const context = canvas.getContext('2d')
    if (!context) return
    const image = context.createImageData(SIZE, SIZE)
    data.forEach((value, index) => {
      const shade = Math.max(0, Math.min(255, ((value + 1000) / 4000) * 255))
      const pixel = index * 4
      image.data[pixel] = shade
      image.data[pixel + 1] = shade
      image.data[pixel + 2] = shade
      image.data[pixel + 3] = 255
    })
    context.putImageData(image, 0, 0)
  }

  const chooseFile = (event: ChangeEvent<HTMLInputElement>) => {
    const selected = event.target.files?.[0]
    if (!selected) return
    setFile(selected)
    setStatus('idle')
    setMessage('File đã sẵn sàng để xử lý')
  }

  const processImage = async () => {
    if (!file) {
      setStatus('error')
      setMessage('Vui lòng chọn file .RAW trước')
      return
    }

    try {
      setStatus('reading')
      setMessage('Đang đọc dữ liệu CT...')
      const raw = new Float32Array(await file.arrayBuffer())
      if (raw.length !== SIZE * SIZE) throw new Error('File phải có kích thước 512 × 512 Float32')
      draw(raw, sourceCanvas.current)

      setStatus('processing')
      setMessage('AI đang khử nhiễu kim loại...')
      const formData = new FormData()
      formData.append('file', file)
      const response = await fetch(API_URL, { method: 'POST', body: formData })
      if (!response.ok) throw new Error('Máy chủ xử lý không thành công')
      draw(new Float32Array(await response.arrayBuffer()), resultCanvas.current)
      setStatus('success')
      setMessage('Đã xử lý xong — kết quả đã sẵn sàng')
    } catch (error) {
      setStatus('error')
      setMessage(error instanceof Error ? error.message : 'Có lỗi không xác định')
    }
  }

  const busy = status === 'reading' || status === 'processing'
  const StatusIcon = status === 'success' ? CheckCircle2 : status === 'error' ? XCircle : busy ? Loader2 : ScanLine

  return (
    <main className="min-h-screen bg-slate-950 px-4 py-8 text-slate-100 sm:px-8">
      <div className="mx-auto max-w-5xl">
        <header className="mb-10 flex items-center justify-between">
          <div>
            <p className="text-sm font-bold tracking-[0.2em] text-blue-400">CT-MAR</p>
            <p className="mt-1 text-xs text-slate-500">AI metal artifact reduction</p>
          </div>
          <span className="rounded-full border border-slate-800 px-3 py-1 text-xs text-slate-500">512 × 512 RAW</span>
        </header>

        <section className="mb-8 max-w-2xl">
          <h1 className="text-3xl font-semibold tracking-tight sm:text-5xl">Khử nhiễu kim loại <span className="text-blue-400">CT</span></h1>
          <p className="mt-3 text-sm leading-6 text-slate-400 sm:text-base">Tải dữ liệu CT, xử lý bằng AI và so sánh kết quả ngay trên một màn hình.</p>
        </section>

        <section className="rounded-2xl border border-slate-800 bg-slate-900 p-4 shadow-xl shadow-black/20 sm:p-5">
          <div className="flex flex-col gap-3 sm:flex-row">
            <button type="button" onClick={() => inputRef.current?.click()} className="flex min-h-14 flex-1 items-center gap-3 rounded-xl border border-dashed border-slate-700 px-4 text-left transition-colors hover:border-blue-400 hover:bg-blue-500/5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-400">
              <Upload className="size-5 text-blue-400" />
              <span className="min-w-0"><strong className="block text-sm">{file ? file.name : 'Chọn file CT'}</strong><small className="block truncate text-xs text-slate-500">{file ? 'Sẵn sàng để xử lý' : 'Định dạng .RAW · Float32'}</small></span>
            </button>
            <input ref={inputRef} type="file" accept=".raw,.RAW" onChange={chooseFile} className="sr-only" />
            <button type="button" onClick={processImage} disabled={!file || busy} className="inline-flex min-h-14 items-center justify-center gap-2 rounded-xl bg-blue-500 px-6 text-sm font-semibold text-white transition-all hover:bg-blue-400 hover:shadow-lg hover:shadow-blue-500/20 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-300 disabled:cursor-not-allowed disabled:opacity-40">
              {busy ? <Loader2 className="size-4 animate-spin" /> : <ScanLine className="size-4" />}
              {busy ? 'Đang xử lý...' : 'Bắt đầu'}
            </button>
          </div>
          <div className={`mt-3 flex items-center gap-2 text-xs ${status === 'error' ? 'text-rose-400' : status === 'success' ? 'text-emerald-400' : 'text-slate-500'}`} role="status"><StatusIcon className={`size-4 ${busy ? 'animate-spin' : ''}`} />{message}</div>
        </section>

        <section className="mt-6 grid gap-4 md:grid-cols-2">
          {[['Ảnh đầu vào', 'Artifact hiện tại', sourceCanvas], ['Kết quả AI', 'Sau khi khử nhiễu', resultCanvas]].map(([title, subtitle, canvasRef]) => (
            <article key={title as string} className="overflow-hidden rounded-2xl border border-slate-800 bg-slate-900 transition-colors hover:border-blue-400/40">
              <div className="border-b border-slate-800 px-4 py-3"><h2 className="text-sm font-medium">{title as string}</h2><p className="mt-1 text-xs text-slate-500">{subtitle as string}</p></div>
              <div className="p-3"><div className="relative aspect-square overflow-hidden rounded-xl bg-black"><canvas ref={canvasRef as React.RefObject<HTMLCanvasElement>} width={SIZE} height={SIZE} className="size-full" />{!file && <div className="absolute inset-0 flex flex-col items-center justify-center gap-2 text-slate-700"><ImageIcon className="size-7" /><span className="text-xs">Chưa có hình ảnh</span></div>}</div></div>
            </article>
          ))}
        </section>

        <p className="mt-6 text-center text-xs text-slate-600">Dữ liệu được xử lý an toàn trong phiên làm việc này.</p>
      </div>
    </main>
  )
}
